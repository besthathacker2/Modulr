#!/usr/bin/env python3
# =============================================================================
# Modulr OS - Welcome App
# First-run experience built with GTK4 + Libadwaita
# =============================================================================

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gio, GLib, Gdk
import subprocess
import os
import sys

APP_ID = "dev.modulros.Welcome"
APP_VERSION = "1.0"


class ModulrWelcomeApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.connect('activate', self.on_activate)

    def on_activate(self, app):
        self.win = WelcomeWindow(application=app)
        self.win.present()


class WelcomeWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_title("Welcome to Modulr OS")
        self.set_default_size(780, 580)
        self.set_resizable(False)

        self.pages = []
        self.current_page = 0

        self._build_ui()

    def _build_ui(self):
        # Main stack
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
        self.stack.set_transition_duration(300)

        # Pages
        self._add_page_welcome()
        self._add_page_appearance()
        self._add_page_updates()
        self._add_page_done()

        # Navigation bar
        nav_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        nav_box.set_margin_bottom(24)
        nav_box.set_margin_start(24)
        nav_box.set_margin_end(24)
        nav_box.set_halign(Gtk.Align.CENTER)

        self.back_btn = Gtk.Button(label="Back")
        self.back_btn.connect('clicked', self.go_back)
        self.back_btn.set_visible(False)

        self.next_btn = Gtk.Button(label="Next")
        self.next_btn.add_css_class('suggested-action')
        self.next_btn.add_css_class('pill')
        self.next_btn.connect('clicked', self.go_next)

        nav_box.append(self.back_btn)
        nav_box.append(self.next_btn)

        # Root layout
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.append(self.stack)
        root.append(nav_box)

        self.set_content(root)

    def _add_page_welcome(self):
        page = Adw.StatusPage()
        page.set_icon_name("start-here-symbolic")
        page.set_title("Welcome to Modulr OS")
        page.set_description(
            "A modern, all-purpose operating system built on Debian.\n"
            "Let's get you set up in just a few steps."
        )
        page.set_vexpand(True)

        # Version badge
        badge = Gtk.Label(label="Version 1.0 · Core")
        badge.add_css_class('dim-label')
        badge.add_css_class('caption')
        page.set_child(badge)

        self.stack.add_titled(page, "welcome", "Welcome")
        self.pages.append("welcome")

    def _add_page_appearance(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        box.set_margin_top(32)
        box.set_margin_bottom(8)
        box.set_margin_start(48)
        box.set_margin_end(48)
        box.set_vexpand(True)

        title = Gtk.Label(label="Appearance")
        title.add_css_class('title-1')
        title.set_halign(Gtk.Align.START)

        subtitle = Gtk.Label(label="Choose your preferred style")
        subtitle.add_css_class('dim-label')
        subtitle.set_halign(Gtk.Align.START)

        # Style toggle
        style_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        style_box.set_halign(Gtk.Align.CENTER)
        style_box.set_margin_top(12)

        self.style_group = Gtk.CheckButton()

        dark_btn = Gtk.CheckButton(label="🌙  Dark")
        dark_btn.set_group(self.style_group)
        dark_btn.set_active(True)
        dark_btn.connect('toggled', self._on_dark_toggled)

        light_btn = Gtk.CheckButton(label="☀️  Light")
        light_btn.set_group(dark_btn)
        light_btn.connect('toggled', self._on_light_toggled)

        style_box.append(dark_btn)
        style_box.append(light_btn)

        # Accent color picker
        accent_label = Gtk.Label(label="Accent Color")
        accent_label.add_css_class('heading')
        accent_label.set_halign(Gtk.Align.START)
        accent_label.set_margin_top(16)

        accent_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        accent_box.set_halign(Gtk.Align.START)

        self.accent_colors = {
            'blue': '#3b82f6',
            'purple': '#8b5cf6',
            'teal': '#14b8a6',
            'green': '#22c55e',
            'orange': '#f97316',
            'red': '#ef4444',
            'pink': '#ec4899',
        }

        for name, color in self.accent_colors.items():
            btn = Gtk.Button()
            btn.set_size_request(32, 32)
            btn.add_css_class('circular')
            btn.set_tooltip_text(name.capitalize())
            btn.connect('clicked', self._set_accent, name)

            # CSS color
            provider = Gtk.CssProvider()
            provider.load_from_data(
                f"button {{ background-color: {color}; min-width: 32px; min-height: 32px; }}".encode()
            )
            btn.get_style_context().add_provider(provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            accent_box.append(btn)

        box.append(title)
        box.append(subtitle)
        box.append(style_box)
        box.append(accent_label)
        box.append(accent_box)

        self.stack.add_titled(box, "appearance", "Appearance")
        self.pages.append("appearance")

    def _add_page_updates(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        box.set_margin_top(32)
        box.set_margin_bottom(8)
        box.set_margin_start(48)
        box.set_margin_end(48)
        box.set_vexpand(True)

        title = Gtk.Label(label="Updates & Privacy")
        title.add_css_class('title-1')
        title.set_halign(Gtk.Align.START)

        # Options list
        list_box = Gtk.ListBox()
        list_box.add_css_class('boxed-list')
        list_box.set_selection_mode(Gtk.SelectionMode.NONE)

        options = [
            ("Download updates automatically", "Keeps your system secure and up to date", True),
            ("Enable crash reporting", "Helps improve Modulr OS (anonymized)", False),
            ("Send diagnostics", "Anonymous hardware compatibility data", False),
        ]

        for label, desc, default in options:
            row = Adw.ActionRow()
            row.set_title(label)
            row.set_subtitle(desc)
            toggle = Gtk.Switch()
            toggle.set_active(default)
            toggle.set_valign(Gtk.Align.CENTER)
            row.add_suffix(toggle)
            row.set_activatable_widget(toggle)
            list_box.append(row)

        box.append(title)
        box.append(list_box)

        self.stack.add_titled(box, "updates", "Updates")
        self.pages.append("updates")

    def _add_page_done(self):
        page = Adw.StatusPage()
        page.set_icon_name("emblem-ok-symbolic")
        page.set_title("You're all set!")
        page.set_description(
            "Modulr OS is ready to use.\n"
            "Explore the App Center to install more software."
        )
        page.set_vexpand(True)
        self.stack.add_titled(page, "done", "Done")
        self.pages.append("done")

    def _on_dark_toggled(self, btn):
        if btn.get_active():
            manager = Adw.StyleManager.get_default()
            manager.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
            try:
                subprocess.run(['gsettings', 'set', 'org.gnome.desktop.interface',
                                'color-scheme', 'prefer-dark'], check=False)
            except Exception:
                pass

    def _on_light_toggled(self, btn):
        if btn.get_active():
            manager = Adw.StyleManager.get_default()
            manager.set_color_scheme(Adw.ColorScheme.FORCE_LIGHT)
            try:
                subprocess.run(['gsettings', 'set', 'org.gnome.desktop.interface',
                                'color-scheme', 'prefer-light'], check=False)
            except Exception:
                pass

    def _set_accent(self, btn, color_name):
        try:
            subprocess.run(['gsettings', 'set', 'org.gnome.desktop.interface',
                            'accent-color', color_name], check=False)
        except Exception:
            pass

    def go_next(self, btn):
        if self.current_page < len(self.pages) - 1:
            self.current_page += 1
            self.stack.set_visible_child_name(self.pages[self.current_page])
            self.back_btn.set_visible(True)

            if self.current_page == len(self.pages) - 1:
                self.next_btn.set_label("Get Started")
                self.next_btn.connect('clicked', lambda b: self.close())
        else:
            # Mark welcome as seen
            config_dir = os.path.expanduser("~/.config/modulr")
            os.makedirs(config_dir, exist_ok=True)
            with open(os.path.join(config_dir, ".welcome-seen"), "w") as f:
                f.write("1")
            self.close()

    def go_back(self, btn):
        if self.current_page > 0:
            self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_RIGHT)
            self.current_page -= 1
            self.stack.set_visible_child_name(self.pages[self.current_page])
            self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
            self.next_btn.set_label("Next")

            if self.current_page == 0:
                self.back_btn.set_visible(False)


def main():
    # Don't show if already seen
    seen_flag = os.path.expanduser("~/.config/modulr/.welcome-seen")
    if os.path.exists(seen_flag) and "--force" not in sys.argv:
        sys.exit(0)

    app = ModulrWelcomeApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
