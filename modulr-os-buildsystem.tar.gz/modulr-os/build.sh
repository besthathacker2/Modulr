#!/bin/bash
# =============================================================================
# Modulr OS - Master Build Script
# Builds bootable ISO for AMD64 and ARM64
# =============================================================================

set -euo pipefail

# --- Config ------------------------------------------------------------------
DISTRO_NAME="Modulr OS"
DISTRO_VERSION="1.0"
CODENAME="core"
DEBIAN_BASE="bookworm"
BUILD_DIR="$(pwd)/build"
OUTPUT_DIR="$(pwd)/output"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

log()     { echo -e "${CYAN}[MODULR]${NC} $1"; }
success() { echo -e "${GREEN}[  OK  ]${NC} $1"; }
warn()    { echo -e "${YELLOW}[ WARN ]${NC} $1"; }
error()   { echo -e "${RED}[ERROR ]${NC} $1"; exit 1; }

# --- Argument Parsing --------------------------------------------------------
ARCH="${1:-amd64}"
case "$ARCH" in
  amd64|arm64) ;;
  both)
    log "Building both architectures..."
    bash "$0" amd64
    bash "$0" arm64
    exit 0
    ;;
  *) error "Usage: $0 [amd64|arm64|both]" ;;
esac

log "Building Modulr OS $DISTRO_VERSION for $ARCH"

# --- Dependency Check --------------------------------------------------------
check_deps() {
  log "Checking dependencies..."
  local deps=(live-build debootstrap xorriso squashfs-tools grub-efi-amd64-bin mtools)
  [ "$ARCH" = "arm64" ] && deps+=(qemu-user-static binfmt-support grub-efi-arm64-bin)

  for dep in "${deps[@]}"; do
    if ! dpkg -l "$dep" &>/dev/null; then
      warn "Missing: $dep — installing..."
      apt-get install -y "$dep" || error "Failed to install $dep"
    fi
  done
  success "All dependencies satisfied"
}

# --- Setup live-build --------------------------------------------------------
setup_lb() {
  log "Setting up live-build for $ARCH..."
  mkdir -p "$BUILD_DIR/$ARCH"
  cd "$BUILD_DIR/$ARCH"

  lb config \
    --architecture "$ARCH" \
    --distribution "$DEBIAN_BASE" \
    --debian-installer live \
    --debian-installer-gui true \
    --bootappend-live "boot=live components quiet splash" \
    --memtest none \
    --iso-application "$DISTRO_NAME" \
    --iso-preparer "Modulr OS Project" \
    --iso-publisher "Modulr OS" \
    --iso-volume "ModulrOS_${DISTRO_VERSION}_${ARCH}" \
    --mirror-bootstrap "http://deb.debian.org/debian/" \
    --mirror-chroot "http://deb.debian.org/debian/" \
    --mirror-binary "http://deb.debian.org/debian/" \
    --apt-indices false \
    --apt-recommends true \
    --packages "apt-transport-https ca-certificates" \
    --firmware-binary true \
    --firmware-chroot true

  # Copy config overlays
  cp -r "$(dirname "$0")/config/"* config/
  success "live-build configured"
}

# --- Build -------------------------------------------------------------------
build_iso() {
  log "Building ISO (this takes 20–60 minutes)..."
  cd "$BUILD_DIR/$ARCH"

  [ "$ARCH" = "arm64" ] && update-binfmts --enable qemu-aarch64

  lb build 2>&1 | tee "../../modulr-build-${ARCH}.log"

  mkdir -p "$OUTPUT_DIR"
  ISO_NAME="ModulrOS_${DISTRO_VERSION}_${ARCH}.iso"
  mv live-image-"${ARCH}".hybrid.iso "$OUTPUT_DIR/$ISO_NAME"
  success "ISO built: $OUTPUT_DIR/$ISO_NAME"

  # Generate checksum
  cd "$OUTPUT_DIR"
  sha256sum "$ISO_NAME" > "${ISO_NAME}.sha256"
  success "Checksum: $OUTPUT_DIR/${ISO_NAME}.sha256"
}

# --- Main --------------------------------------------------------------------
check_deps
setup_lb
build_iso

echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  Modulr OS $DISTRO_VERSION ($ARCH) build complete!${NC}"
echo -e "${GREEN}============================================${NC}"
echo -e "  ISO: ${CYAN}$OUTPUT_DIR/ModulrOS_${DISTRO_VERSION}_${ARCH}.iso${NC}"
echo ""
echo -e "  Test with QEMU:"
if [ "$ARCH" = "amd64" ]; then
  echo -e "  ${YELLOW}qemu-system-x86_64 -m 4G -cdrom output/ModulrOS_${DISTRO_VERSION}_amd64.iso -boot d${NC}"
else
  echo -e "  ${YELLOW}qemu-system-aarch64 -M virt -cpu cortex-a72 -m 4G -bios /usr/share/qemu-efi-aarch64/QEMU_EFI.fd -cdrom output/ModulrOS_${DISTRO_VERSION}_arm64.iso${NC}"
fi
